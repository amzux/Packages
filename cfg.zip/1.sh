#!/bin/bash
while true
do
	NET=$(ping -q -w 1 -c 1 `ip r | grep default | cut -d ' ' -f 3` > /dev/null && echo ok || echo error)
	if [ "$NET" = "ok" ]; then
		./ngrok tcp 22 > /dev/null &
		PID_NG=$!
		ping -w 5 0.tcp.ngrok.io > config.txt
		curl http://127.0.0.1:4040/api/tunnels >> config.txt
		PID_NC=$!
		python mail.py
                python mail2.py
		sleep 20
		rm config.txt
		kill PID_NG
		kill PID_NC
		sleep 5
	fi
	sleep 5
done


